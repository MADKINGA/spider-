from django.apps import AppConfig


class DoubanappConfig(AppConfig):
    name = 'doubanapp'
